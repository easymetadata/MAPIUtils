﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.IO;

namespace Mapi_Decode_ConvId

{
    public static class ExchangeStoreReference
    {
        public static string DecodeEntryId(BinaryReader reader, string baseUrl)
        {
            Guid folderId;
            ulong folderCnt;

            // First reserved field
            var freserved1 = reader.ReadUInt32();

            // Now comes the store guid.
            var storeguid = reader.ReadBytes(16);

            // Next reserved field
            var freserved2 = reader.ReadUInt16();

            folderId = ReadGuid(reader);
            folderCnt = SwapUInt64(reader.ReadUInt64());

            if (!baseUrl.EndsWith("/"))
            {
                baseUrl += "/";
            }

            if (reader.BaseStream.Length - reader.BaseStream.Position >= 24)
            {
                Guid messageId;
                messageId = ReadGuid(reader);
                ulong messageCnt;
                messageCnt = SwapUInt64(reader.ReadUInt64());

                var sOut = string.Format("{0}, {1:}, {2}, {3}", folderId, folderCnt, messageId, messageCnt);

                Console.WriteLine("folderId, folderCnt, messageId, messageCnt");
                Console.WriteLine(sOut);
                //baseUrl += string.Format(CultureInfo.CurrentCulture, baseUrl + "/ -FlatUrlSpace -/{ 0:N}-{ 1:x}/{ 2:N}-{ 3:x}", folderId, folderCnt, messageId, messageCnt);
            }
            else
            {
                baseUrl += string.Format(CultureInfo.CurrentCulture, baseUrl + "/ -FlatUrlSpace -/{ 0:N}-{ 1:x}", folderId, folderCnt);
            }

            return baseUrl;
        }

        public static string DecodeEntryIdOnly(BinaryReader reader)
        {
            var baseUrl = string.Empty;

            Guid folderId;
            ulong folderCnt;

            // First reserved field
            reader.ReadUInt32();

            // Now comes the store guid.
            reader.ReadBytes(16);

            // Next reserved field
            reader.ReadUInt16();

            folderId = ReadGuid(reader);
            folderCnt = SwapUInt64(reader.ReadUInt64());


            string smessageId = string.Empty;
            if (reader.BaseStream.Length - reader.BaseStream.Position >= 24)
            {
                Guid messageId;
                messageId = ReadGuid(reader);
                ulong messageCnt;
                messageCnt = SwapUInt64(reader.ReadUInt64());
                //baseUrl += string.Format(CultureInfo.CurrentCulture, baseUrl + "/ -FlatUrlSpace -/{ 0:N}-{ 1:x}/{ 2:N}-{ 3:x}", folderId, folderCnt, messageId, messageCnt);
                smessageId = messageId.ToString();
            }
            else
            {
                //baseUrl += string.Format(CultureInfo.CurrentCulture, baseUrl + "/ -FlatUrlSpace -/{ 0:N}-{ 1:x}", folderId, folderCnt);
            }

            return smessageId;
        }

        private static Guid ReadGuid(BinaryReader reader)
        {
            int a;
            short b, c;
            a = SwapInt(reader.ReadUInt32());
            b = reader.ReadInt16();
            c = SwapShort(reader.ReadUInt16());
            return new Guid(a, b, c, reader.ReadBytes(8));
        }

        private static short SwapShort(ushort value)
        {
            unchecked
            {
                ushort result;
                result = (ushort)(((value & 0xFF00) >> 8) | ((value & 0x00FF) << 8));

                //ushort to short
                var sOut = short.Parse(result.ToString("X"), NumberStyles.HexNumber);
                return (short)sOut;
            }
        }

        private static int SwapInt(uint value)
        {
            uint result;
            result = ((value & 0xFF000000) >> 24) |
            ((value & 0x00FF0000) >> 8) |
            ((value & 0x0000FF00) << 8) |
            ((value & 0x000000FF) << 24);
            unchecked
            {
                return (int)result;
            }
        }

        private static ulong SwapUInt64(ulong value)
        {
            //uint uv = Convert.ToUInt32(value);

            uint lo;
            //uint hi;
            ulong result;
            lo = (uint)(value & 0xffffffff);
            uint hi = (uint)(value >> (32)) & 0xffffffff;

            lo = ((lo & 0xFF000000) >> 8) |
            ((lo & 0x00FF0000) << 8) |
            ((lo & 0x0000FF00) >> 8) |
            ((lo & 0x000000FF) << 8);

            hi = ((hi & 0xFF000000) >> 8) |
            ((hi & 0x00FF0000) << 8) |
            ((hi & 0x0000FF00) >> 8) |
            ((hi & 0x000000FF) << 8);
            result = (((ulong)lo) << 32) | hi;

            return result;
        }
    }
}
