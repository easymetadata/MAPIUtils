﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Mapi_Decode_ConvId
{
    class Program
    {
        static void Main(string[] args)
        {
            //var sentryid = "000000004E4CB78A6AA60F49AC242AF35F1C4C29070081214A5F265A094DBEC8FEF79125F87400000000010C000081214A5F265A094DBEC8FEF79125F8740000B66DDF010000";
            //var sentryid = "000000004E4CB78A6AA60F49AC242AF35F1C4C29070081214A5F265A094DBEC8FEF79125F87400000000635D000081214A5F265A094DBEC8FEF79125F874000008A02AD30000";
            string sentryid = args[0];
            //string sentryid = "4E4CB78A6AA60F49AC242AF35F1C4C29070081214A5F265A094DBEC8FEF79125F87400000000010C000081214A5F265A094DBEC8FEF79125F8740000B66DDF010000";

            Console.WriteLine(string.Empty);
            Console.WriteLine("entryId input:");
            Console.WriteLine(sentryid);
            Console.WriteLine(string.Empty);

            byte[] arr = System.Text.Encoding.ASCII.GetBytes(sentryid);
            using (MemoryStream memory = new MemoryStream(arr))
            {
                
                var _decode = ExchangeStoreReference.DecodeEntryId(new System.IO.BinaryReader(memory), string.Empty);
            }
        }

    }
}
